print("Mate Giorgelashvili")
print("ირაკლი კვინჩია")
print("Saba Isakadze")