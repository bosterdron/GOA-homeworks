print(5 > 3)
print(4 > 2)
print(1 > 2)

print(6 < 7)
print(4 < 8)
print(5 < 4)

print(5 == 5)
print(5 == 3)
print(3 == 2)

print(3 != 2)
print(6 != 6)
print(6 != 4)