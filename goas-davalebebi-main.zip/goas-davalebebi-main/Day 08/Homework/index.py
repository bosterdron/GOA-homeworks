num1 = input("enter your number:")
num2 = input("enter your number:")

print(num1 != num2)
print(num1 <= num2)
print(num1 >= num2)
print(num1 > num2)
print(num1 < num2)