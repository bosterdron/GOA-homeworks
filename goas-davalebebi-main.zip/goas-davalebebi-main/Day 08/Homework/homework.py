print(5 == 6)  # False, because 5 is not equal to 6
print(5 != 6)  # True, because 5 is not equal to 6
print(5 <= 6)  # True, because 5 is less than or equal to 6
print(5 >= 6)  # False, because 5 is not greater than or equal to 6
print(5 > 6)   # False, because 5 is not greater than 6
print(5 < 6)   # True, because 5 is less than 6