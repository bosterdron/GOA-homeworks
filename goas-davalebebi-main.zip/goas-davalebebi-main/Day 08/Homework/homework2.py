x = 10
print(x)
x = -x
print(x)