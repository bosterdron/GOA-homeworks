balance = 1000
discount = 200

final_price = balance - discount

print(final_price)