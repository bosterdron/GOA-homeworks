name = "giorgi"
surname = "chaduneli"
age = 15

print("My name is" + " " + name + " my surname is" + " " + surname + " my age is" + " " + str(age))