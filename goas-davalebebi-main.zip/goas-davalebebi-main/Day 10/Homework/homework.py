for i in range(1, 11):
    print(i)
    print("Hello world!")


total_sum = 0
for i in range(1, 11):
    total_sum += i
print("Total sum:", total_sum)


for i in range(0, 1001, 100):
    print(i)


for i in range(100, -1, -1):
    print(i)


i = 1
while i <= 10:
    print(i)
    print("Hello world!")
    i += 1

total_sum = 0
counter = 1
while counter <= 10:
    total_sum += counter
    counter += 1
print("Total sum:", total_sum)


i = 0
while i <= 1000:
    print(i)
    i += 100


counter = 0
while counter <= 10:
    print(counter)
    print("Hello world!")
    counter += 1

counter = 0
while counter <= 1000:
    print(counter)
    counter += 100
