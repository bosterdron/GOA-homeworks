print(True or False)
print(False or True)
print(True and True)
print(True and False)
print(False and True)
print(False and False)

print(not True)
print(not False)

age = 14
have_ticket = True
print(age <= 18 and have_ticket)

print(5 < 10 and 5 > 10)

counter = 1
while counter <= 100:
    print(counter)
    counter = counter + 1


counter = 1
while counter <= 10:
    print(counter)
    counter = counter + 2


counter = 100
while counter >= 1:
    print(counter)
    counter = counter - 1
