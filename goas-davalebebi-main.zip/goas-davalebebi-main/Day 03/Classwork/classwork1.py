num1 = 14
num2 = 10.19
num3 = True
num4 = "Int"

print(type(num1))
print(type(num2))
print(type(num3))
print(type(num4))